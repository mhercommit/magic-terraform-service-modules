// index.js
const { sigV4ASignBasic } = require('./sigv4a_sign');

const failoverHeader = 'originTypeFailover';
const cfReadOnlyHeadersList = [
  'Accept-Encoding',
  'Content-Length',
  'If-Modified-Since',
  'If-None-Match',
  'If-Range',
  'If-Unmodified-Since',
  'Transfer-Encoding',
  'Via',
  'via',
];

exports.handler = async (event, context) => {
  const request = event.Records[0].cf.request;


  const originKey = Object.keys(request.origin)[0];
  const customHeaders = request.origin[originKey].customHeaders || {};

  if (failoverHeader in customHeaders) {
    return request;
  }

  const method = request.method;
  const endpoint = `https://${request.origin.custom.domainName}${request.uri}`;
  const headers = request.headers;

  delete headers['x-forwarded-for'];

  const cfReadOnlyHeaders = {};
  cfReadOnlyHeadersList.forEach(h => {
    if (headers[h]) {
      cfReadOnlyHeaders[h] = [headers[h][0].value];
    }
  });

  const xForwardedForHeader = request.headers['x-forwarded-for'];
  if (xForwardedForHeader && xForwardedForHeader.length > 0) {
    cfReadOnlyHeaders['x-forwarded-for'] = [xForwardedForHeader[0].value];
  }

  cfReadOnlyHeaders['X-Amz-Cf-Id'] = [event.Records[0].cf.config.requestId];

  const signedHeaders = sigV4ASignBasic(method, endpoint, 's3', cfReadOnlyHeaders);

  for ( item of signedHeaders._flatten() ) { headers[item[0]]=[{key:item[0], value:item[1]}] }


  for (const [key, value] of Object.entries(cfReadOnlyHeaders)) {
    headers[key] = [{ key, value: value[0] }];
  }

  delete headers['X-Amz-Cf-Id'];

  request.headers = headers;
  delete request.querystring;

  return request;
};